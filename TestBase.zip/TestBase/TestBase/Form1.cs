using System;
using System.Data.SQLite;
using System.Windows.Forms;
using OfficeOpenXml;
using System.IO;

namespace TestBase
{
    public partial class Form1 : Form
    {
        private SQLiteConnection sqliteConnection;
        private TextBox roomNameTextBox;
        private Button saveButton;
        private ComboBox roomNamesComboBox;

        public Form1()
        {
            InitializeComponent();
            InitializeDatabase();
            InitializeUI();
        }

        private void InitializeDatabase()
        {
            sqliteConnection = new SQLiteConnection("Data Source=database.db;Version=3;");
            sqliteConnection.Open();

            string createTableQuery = "CREATE TABLE IF NOT EXISTS Rooms (Id INTEGER PRIMARY KEY, RoomName TEXT)";
            SQLiteCommand createTableCommand = new SQLiteCommand(createTableQuery, sqliteConnection);
            createTableCommand.ExecuteNonQuery();
        }

        private void InitializeUI()
        {
            // Create and configure the TextBox for entering room names
            roomNameTextBox = new TextBox();
            roomNameTextBox.Location = new System.Drawing.Point(10, 10);
            roomNameTextBox.Width = 200;
            this.Controls.Add(roomNameTextBox);

            // Create and configure the Save Button
            saveButton = new Button();
            saveButton.Text = "Save Room Name";
            saveButton.Location = new System.Drawing.Point(220, 10);
            saveButton.Click += new EventHandler(SaveButton_Click);
            this.Controls.Add(saveButton);

            // Create and configure the ComboBox for displaying room names
            roomNamesComboBox = new ComboBox();
            roomNamesComboBox.Location = new System.Drawing.Point(10, 40);
            roomNamesComboBox.Width = 200;
            this.Controls.Add(roomNamesComboBox);

            //Button to Export to Excel
            Button exportButton = new Button();
            exportButton.Text = "Export to Excel";
            exportButton.Location = new System.Drawing.Point(10, 70);
            exportButton.Click += (sender, e) => ExportToExcel();
            this.Controls.Add(exportButton);

            // Load existing room names into the ComboBox
            LoadRoomNames();
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            string roomName = roomNameTextBox.Text;
            if (!string.IsNullOrEmpty(roomName))
            {
                string insertQuery = "INSERT INTO Rooms (RoomName) VALUES (@RoomName)";
                SQLiteCommand insertCommand = new SQLiteCommand(insertQuery, sqliteConnection);
                insertCommand.Parameters.AddWithValue("@RoomName", roomName);
                insertCommand.ExecuteNonQuery();
                MessageBox.Show("Room name saved successfully!");
                roomNameTextBox.Clear();
                LoadRoomNames(); // Refresh the list of room names in the ComboBox
            }
            else
            {
                MessageBox.Show("Please enter a room name.");
            }
        }
        private void LoadRoomNames()
        {
            string query = "SELECT RoomName FROM Rooms";
            SQLiteCommand command = new SQLiteCommand(query, sqliteConnection);
            SQLiteDataReader reader = command.ExecuteReader();

            roomNamesComboBox.Items.Clear();
            while (reader.Read())
            {
                roomNamesComboBox.Items.Add(reader["RoomName"].ToString());
            }
        }
        public void ExportToExcel()
        {
            string query = "SELECT * FROM Rooms";
            SQLiteCommand command = new SQLiteCommand(query, sqliteConnection);
            SQLiteDataReader reader = command.ExecuteReader();

            // Configure the Excel package
            using (var package = new ExcelPackage())
            {
                var worksheet = package.Workbook.Worksheets.Add("Rooms");

                // Add header row
                worksheet.Cells[1, 1].Value = "Id";
                worksheet.Cells[1, 2].Value = "RoomName";

                int row = 2; // Starting from the second row to leave space for headers

                // Populate Excel rows with data from the SQLite reader
                while (reader.Read())
                {
                    worksheet.Cells[row, 1].Value = reader["Id"];
                    worksheet.Cells[row, 2].Value = reader["RoomName"];
                    row++;
                }

                // Save the Excel file to a specific location
                string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "RoomsData.xlsx");
                FileInfo file = new FileInfo(filePath);
                package.SaveAs(file);

                MessageBox.Show($"Data exported to {filePath} successfully!");
            }
        }
    }
}
